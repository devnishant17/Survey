const express = require('express');
const mongoose = require('mongoose');
const authRoutes = require('./routes/authRoutes');
const surveyRoutes = require('./routes/surveyRoutes');
const bonusRoutes = require('./routes/bonusRoutes'); // For Bonus tasks
const { authenticateToken } = require('./middlewares/authMiddleware');
const config = require('./config');

const app = express();
app.use(express.json());

// Routes
app.use('/auth', authRoutes);
app.use('/survey', authenticateToken, surveyRoutes);
app.use('/bonus', authenticateToken, bonusRoutes); // For Bonus tasks

// Database connection
mongoose.connect(config.DB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to DB'))
  .catch(err => console.error(err));

app.listen(config.PORT, () => {
  console.log(`Server is running on port ${config.PORT}`);
});
