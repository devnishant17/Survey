const jwt = require('jsonwebtoken');
const config = require('../config');

exports.login = (req, res) => {
  const { username, password } = req.body;
  const token = jwt.sign({ username }, config.JWT_SECRET, { expiresIn: '1h' });
  res.json({ token });
};
