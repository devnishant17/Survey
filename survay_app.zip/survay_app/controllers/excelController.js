const ExcelJS = require('exceljs');

exports.generateExcel = async (req, res) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Survey Results');
  
  worksheet.addRow(['Survey Title', 'Response']);
  worksheet.addRow(['Sample Survey', 'Yes, No, Yes']);
  
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=survey-results.xlsx');
  
  await workbook.xlsx.write(res);
  res.end();
};
