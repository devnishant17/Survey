const Survey = require('../models/Survey');

exports.createSurvey = async (req, res) => {
  const { title, questions } = req.body;
  const survey = new Survey({ title, questions });
  await survey.save();
  res.json(survey);
};

exports.takeSurvey = async (req, res) => {
  const { answers } = req.body;
  const survey = await Survey.findById(req.params.id);
  if (!survey) return res.status(404).send('Survey not found');
  
  survey.responses.push({ user: req.user.username, answers });
  await survey.save();
  res.json(survey);
};

exports.getSurveyResults = async (req, res) => {
  const survey = await Survey.findById(req.params.id);
  if (!survey) return res.status(404).send('Survey not found');
  res.json(survey.responses);
};
