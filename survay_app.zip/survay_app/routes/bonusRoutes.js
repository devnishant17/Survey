const express = require('express');
const { generateThumbnail } = require('../controllers/imageController');
const { generateExcel } = require('../controllers/excelController');
const router = express.Router();

router.post('/thumbnail', generateThumbnail);
router.get('/generate-excel', generateExcel);

module.exports = router;
