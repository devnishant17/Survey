const express = require('express');
const { createSurvey, takeSurvey, getSurveyResults } = require('../controllers/surveyController');
const router = express.Router();

router.post('/', createSurvey);
router.post('/:id', takeSurvey);
router.get('/:id/results', getSurveyResults);

module.exports = router;
